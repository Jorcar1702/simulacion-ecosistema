package simulacionEcosistema.negocio;

public class Especie {
    private String nombre;
    private String tipo;
    private double tasaReproduccion;
    private double tasaMortalidad;

    public Especie(String nombre, String tipo, double tasaReproduccion, double tasaMortalidad){
        this.nombre=nombre;
        this.tipo=tipo;
        this.tasaReproduccion=tasaReproduccion;
        this.tasaMortalidad=tasaMortalidad;

    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getTasaReproduccion() {
        return tasaReproduccion;
    }

    public void setTasaReproduccion(double tasaReproduccion) {
        this.tasaReproduccion = tasaReproduccion;
    }

    public double getTasaMortalidad() {
        return tasaMortalidad;
    }

    public void setTasaMortalidad(double tasaMortalidad) {
        this.tasaMortalidad = tasaMortalidad;
    }

    public boolean validarViabilidad(){
        if(tasaReproduccion>tasaMortalidad && tasaReproduccion >0){
            return true;
        }else {
            return false;
        }
    }
    public void registrarEspecie(){
        if(validarViabilidad()){
            System.out.println("Especie registrada"+nombre+"y su Tipo es: "+tipo);
        }
    }
    public void mostrarInformacion(){
        System.out.println("Especie: " + nombre + " (" + tipo + ")");
        System.out.println("Tasa de reproducción: " + tasaReproduccion);
        System.out.println("Tasa de mortalidad: " + tasaMortalidad);

        if (validarViabilidad()) {
            System.out.println("Viabilidad: Viable");
        } else {
            System.out.println("Viabilidad: No viable");
        }
    }
}

