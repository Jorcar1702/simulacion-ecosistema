package simulacionEcosistema.negocio;

import java.util.ArrayList;
import java.util.List;
public class Entorno {
    private int alimentoDisponible;     // cantidad de alimento en el ecosistema
    private int tasaConsumo;            // consumo por turno
    private int regeneracionVegetal;    // regeneración de recursos por turno
    private List<String> alertas;       // lista de alertas generadas

    public Entorno(int alimentoDisponible, int tasaConsumo, int regeneracionVegetal){
        this.alimentoDisponible = alimentoDisponible;
        this.tasaConsumo = tasaConsumo;
        this.regeneracionVegetal = regeneracionVegetal;
        this.alertas = new ArrayList<>();
    }

    // RF7: Calcular consumo de recursos
    public void calcularConsumo(Poblacion poblacion){
        int consumoTotal = poblacion.getCantidad() * tasaConsumo;
        alimentoDisponible -= consumoTotal;
        if(alimentoDisponible < 0){
            alimentoDisponible = 0;
            generarAlerta("Recursos agotados para la especie " + poblacion.getEspecie().getNombre());
        }
    }

    // RF8: Generar alerta de desequilibrio
    public void generarAlerta(String mensaje){
        alertas.add(mensaje);
        System.out.println("ALERTA: " + mensaje);
    }

    // Actualizar recursos (regeneración vegetal)
    public void actualizarRecursos(){
        alimentoDisponible += regeneracionVegetal;
    }

    // Mostrar información del entorno
    public void mostrarInformacion(){
        System.out.println("Alimento disponible: " + alimentoDisponible);
        System.out.println("Tasa de consumo: " + tasaConsumo);
        System.out.println("Regeneración vegetal: " + regeneracionVegetal);
        if(!alertas.isEmpty()){
            System.out.println("Alertas:");
            for(String alerta : alertas){
                System.out.println("- " + alerta);
            }
        }
    }

    // Getters
    public int getAlimentoDisponible(){
        return alimentoDisponible; }
    public int getTasaConsumo(){
        return tasaConsumo; }
    public int getRegeneracionVegetal(){
        return regeneracionVegetal; }
    public List<String> getAlertas(){
        return alertas; }
}


