package simulacionEcosistema.negocio;

public class Interaccion {
    private int factorCaza;
    private double eficienciaConversion;

    public Interaccion(int factorCaza, double eficienciaConversion){
        this.factorCaza = factorCaza;
        this.eficienciaConversion = eficienciaConversion;
    }

    public int getFactorCaza() {
        return factorCaza;
    }

    public void setFactorCaza(int factorCaza) {
        this.factorCaza = factorCaza;
    }

    public double getEficienciaConversion() {
        return eficienciaConversion;
    }

    public void setEficienciaConversion(double eficienciaConversion) {
        this.eficienciaConversion = eficienciaConversion;
    }
    public int simularCaza(Poblacion presas, Poblacion depredadores){
        int presasCazadas = depredadores.getCantidad() * factorCaza;
        if(presasCazadas > presas.getCantidad()){
            presasCazadas = presas.getCantidad();
        }
        presas.setCantidad(presas.getCantidad() - presasCazadas);
        return presasCazadas;
    }
    public void transferirEnergia(Poblacion depredadores, int presasCazadas){
        int nuevosDepredadores = (int)(presasCazadas * eficienciaConversion);
        depredadores.setCantidad(depredadores.getCantidad() + nuevosDepredadores);
    }
}
