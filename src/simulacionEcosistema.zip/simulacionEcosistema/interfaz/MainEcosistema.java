package simulacionEcosistema.interfaz;

import simulacionEcosistema.negocio.*;
import simulacionEcosistema.util.Simulacion;

import java.util.Scanner;

public class MainEcosistema {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Crear entorno inicial y simulación
        Entorno entorno = new Entorno(1000, 1, 50);
        Simulacion simulacion = new Simulacion(10, entorno);

        int op;
        do {
            menu();
            op = Integer.parseInt(sc.nextLine());
            switch (op) {
                case 1: { // Agregar especie
                    System.out.print("Nombre de la especie: ");
                    String nombre = sc.nextLine();
                    System.out.print("Tipo (Herbívoro/Carnívoro/Planta): ");
                    String tipo = sc.nextLine();
                    System.out.print("Tasa de reproducción: ");
                    double tasaR = Double.parseDouble(sc.nextLine());
                    System.out.print("Tasa de mortalidad: ");
                    double tasaM = Double.parseDouble(sc.nextLine());

                    Especie e = new Especie(nombre, tipo, tasaR, tasaM);
                    System.out.println("Especie agregada: " + e);
                } break;

                case 2: { // Agregar población
                    System.out.print("Nombre de la especie: ");
                    String nombre = sc.nextLine();
                    System.out.print("Cantidad inicial: ");
                    int cantidad = Integer.parseInt(sc.nextLine());
                    System.out.print("Capacidad máxima: ");
                    int capacidad = Integer.parseInt(sc.nextLine());

                    // Aquí deberías buscar la especie ya creada, por simplicidad se crea una nueva
                    Especie especie = new Especie(nombre, "Herbívoro", 0.3, 0.1);
                    Poblacion p = new Poblacion(cantidad, capacidad, especie);
                    simulacion.agregarPoblacion(p);
                    System.out.println("Población agregada: " + especie.getNombre() + " con " + cantidad + " individuos.");
                } break;

                case 3: { // Mostrar poblaciones
                    for (Poblacion p : simulacion.getPoblaciones()) {
                        System.out.println(p.getEspecie().getNombre() + ": " + p.getCantidad());
                    }
                } break;

                case 4: { // Ejecutar un turno
                    simulacion.avanzarTurno();
                } break;

                case 5: { // Mostrar estado general
                    simulacion.mostrarEstado();
                } break;

                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }
        } while (op != 6);

        sc.close();
    }

    public static void menu() {
        System.out.println("\n*********** Simulación Ecosistema **********");
        System.out.println("1. Agregar especie");
        System.out.println("2. Agregar población");
        System.out.println("3. Mostrar poblaciones");
        System.out.println("4. Ejecutar un turno");
        System.out.println("5. Mostrar estado general");
        System.out.println("6. Salir");
        System.out.print("Ingrese una opción: ");
    }
}
