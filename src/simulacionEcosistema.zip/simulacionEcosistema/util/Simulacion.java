package simulacionEcosistema.util;

import simulacionEcosistema.negocio.*;
import java.util.ArrayList;
import java.util.List;

public class Simulacion {
    private List<Poblacion> poblaciones;
    private List<Interaccion> interacciones;
    private Entorno entorno;
    private int tiempoTotal;
    private int turnoActual;

    public Simulacion(int tiempoTotal, Entorno entorno){
        this.poblaciones = new ArrayList<>();
        this.interacciones = new ArrayList<>();
        this.entorno = entorno;
        this.tiempoTotal = tiempoTotal;
        this.turnoActual = 0;
    }
    public List<Poblacion> getPoblaciones(){
        return poblaciones;
    }

    // Getter para interacciones (opcional)
    public List<Interaccion> getInteracciones(){
        return interacciones;
    }

    // Cargar poblaciones iniciales
    public void cargarPoblaciones(){
        Especie conejo = new Especie("Conejo","Herbívoro",0.3,0.1);
        Especie zorro = new Especie("Zorro","Carnívoro",0.2,0.05);

        poblaciones.add(new Poblacion(100,200,conejo));
        poblaciones.add(new Poblacion(20,50,zorro));
    }

    // Agregar población manualmente
    public void agregarPoblacion(Poblacion p){
        poblaciones.add(p);
    }

    // Agregar interacción
    public void agregarInteraccion(Interaccion i){
        interacciones.add(i);
    }

    // Buscar población por especie
    public Poblacion buscarPoblacion(String nombreEspecie){
        for(Poblacion p : poblaciones){
            if(p.getEspecie().getNombre().equalsIgnoreCase(nombreEspecie)){
                return p;
            }
        }
        return null;
    }

    // Avanzar un turno
    public void avanzarTurno(){
        turnoActual++;
        System.out.println("Turno " + turnoActual + " en ejecución...");

        for(Poblacion p : poblaciones){
            p.actualizarPoblacion();
            entorno.calcularConsumo(p);
        }

        for(Interaccion i : interacciones){
            if(poblaciones.size() >= 2){
                Poblacion presas = poblaciones.get(0);
                Poblacion depredadores = poblaciones.get(1);
                int presasCazadas = i.simularCaza(presas, depredadores);
                i.transferirEnergia(depredadores, presasCazadas);
            }
        }

        entorno.actualizarRecursos();
    }

    // Mostrar colecciones (similar a mostrarColeccion en SistemaVenta)
    public String mostrarColeccion(List<?> lista){
        StringBuilder sb = new StringBuilder();
        for(Object o : lista){
            sb.append(o.toString()).append("\n");
        }
        return sb.toString();
    }

    // Mostrar estado general
    public void mostrarEstado(){
        System.out.println("=== Estado del Ecosistema ===");
        for(Poblacion p : poblaciones){
            p.mostrarInformacion();
        }
        entorno.mostrarInformacion();
    }
}
